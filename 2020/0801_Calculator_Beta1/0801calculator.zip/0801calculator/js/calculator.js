// let ボタンまとめ

let Num00=document.getElementById("00key");
let Num0=document.getElementById("0key");
let Num1=document.getElementById("1key");
let Num2=document.getElementById("2key");
let Num3=document.getElementById("3key");
let Num4=document.getElementById("4key");
let Num5=document.getElementById("5key");
let Num6=document.getElementById("6key");
let Num7=document.getElementById("7key");
let Num8=document.getElementById("8key");
let Num9=document.getElementById("9key");

let Ope1=document.getElementById("Opekey1");
let Ope2=document.getElementById("Opekey2");
let Ope3=document.getElementById("Opekey3");
let Ope4=document.getElementById("Opekey4");

let Clear=document.getElementById("Ckey");
let AC=document.getElementById("ACkey");

let Dot=document.getElementById("Dotkey");
let Per=document.getElementById("Perkey");

let Equal=document.getElementById("Equalkey");


// 内部
let Ans="";
let Temp="";
let Formula="";
let Total="";
let DotCount=0;
let AnsCount=0;

// 計算カウンタ
let Ope1Count=0;
let OS1=0;
let Ope2Count=0;
let OS2=0;
let Ope3Count=0;
let OS3=0;
let Ope4Count=0;
let OS4=0;


// 表示

Num00.onclick=function(){
  Formula=Formula+"00";
  document.getElementById("CalAns").value=Number(Formula).toLocaleString();
  // CalAnsをletでまとめるとうまいこと動作しない
  
  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}
Num0.onclick=function(){
  Formula=Formula+"0";
  document.getElementById("CalAns").value=Number(Formula).toLocaleString();
  
  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}
Num1.onclick=function(){
  Formula=Formula+"1";
  document.getElementById("CalAns").value=Number(Formula).toLocaleString();
  
  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}
Num2.onclick=function(){
  Formula=Formula+"2";
  document.getElementById("CalAns").value=Number(Formula).toLocaleString();
  
  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}
Num3.onclick=function(){
  Formula=Formula+"3";
  document.getElementById("CalAns").value=Number(Formula).toLocaleString();
  
  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}
Num4.onclick=function(){
  Formula=Formula+"4";
  document.getElementById("CalAns").value=Number(Formula).toLocaleString();
  
  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}
Num5.onclick=function(){
  Formula=Formula+"5";
  document.getElementById("CalAns").value=Number(Formula).toLocaleString();
  
  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}
Num6.onclick=function(){
  Formula=Formula+"6";
  document.getElementById("CalAns").value=Number(Formula).toLocaleString();
  
  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}
Num7.onclick=function(){
  Formula=Formula+"7";
  document.getElementById("CalAns").value=Number(Formula).toLocaleString();
  
  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}
Num8.onclick=function(){
  Formula=Formula+"8";
  document.getElementById("CalAns").value=Number(Formula).toLocaleString();
  
  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}
Num9.onclick=function(){
  Formula=Formula+"9";
  document.getElementById("CalAns").value=Number(Formula).toLocaleString();
  
  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}

Dot.onclick=function(){
  if(DotCount==0){
    DotCount++;
    
    if(!Formula){
      Formula="0.";
      document.getElementById("CalAns").value=Formula.toLocaleString();
      
    }else{
      Formula=Formula+".";
      document.getElementById("CalAns").value=Formula.toLocaleString();
    }
  }
  
  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}

Per.onclick=function(){
  if(AnsCount==1){
    Formula=Ans;
    AnsCount=0;
  }

  Formula=Number(Formula)/100;
  document.getElementById("CalAns").value=Number(Formula).toLocaleString();

  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}

Clear.onclick=function(){
  Formula="";
  document.getElementById("CalAns").value=Formula.toLocaleString();
  DotCount=0;

  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}
AC.onclick=function(){
  Ans="";
  Formula="";
  Total="";
  Temp="";
  document.getElementById("CalAns").value=Formula.toLocaleString();
  DotCount=0;
  AnsCount=0;
  Ope1Count=0;
  Ope2Count=0;
  Ope3Count=0;
  Ope4Count=0;

  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
}

Equal.onclick=function(){
  if(!Total){
    Ans=Formula;
  }
  
  // 加算
  if(Ope1Count==-1){
    Temp=Ans;
    Ans=Temp+Number(Formula);
  }
  if(Ope1Count==1){
    Temp=Total+Number(Formula);
    Ans=Temp;
    Ope1Count=-1;
  }
  
  // 減算
  if(Ope2Count==-1){
    Temp=Ans;
    Ans=Temp-Number(Formula);
  }
  if(Ope2Count==1){
    Temp=Total-Number(Formula);
    Ans=Temp;
    Ope2Count=-1;
  }
  // 乗算
  if(Ope3Count==-1){
    Temp=Ans;
    Ans=Temp*Number(Formula);
  }
  if(Ope3Count==1){
    Temp=Total*Number(Formula);
    Ans=Temp;
    Ope3Count=-1;
  }
  // 除算
  if(Ope4Count==-1){
    Temp=Ans;
    Ans=Temp/Number(Formula);
  }
  if(Ope4Count==1){
    Temp=Total/Number(Formula);
    Ans=Temp;
    Ope4Count=-1;
  }


  document.getElementById("CalAns").value=Number(Ans).toLocaleString();
  AnsCount=1;
  // Formula=Ans;
  DotCount=0;


  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";

  
}



// 計算部分
// 加算
Ope1.onclick=function(){
  if(AnsCount==1){
    Formula=Ans;
  }

  if(Ope2Count!=0){
    Formula=Total-Number(Formula);
    document.getElementById("CalAns").value=Number(Formula).toLocaleString();

  }else if(Ope3Count!=0){
    Formula=Total*Number(Formula);
    document.getElementById("CalAns").value=Number(Formula).toLocaleString();

  }else if(Ope4Count!=0){
    Formula=Total/Number(Formula);
    document.getElementById("CalAns").value=Number(Formula).toLocaleString();

  }
  
  Total=Number(Formula);
  Formula="";
  
  Ope1Count=1;
  Ope2Count=0;
  Ope3Count=0;
  Ope4Count=0;
  
  DotCount=0;
  if(Ope1Count==1){
    Ope1.style.boxShadow="none";
    Ope1.style.transform="translate(2px,2px)";
    Ope1.style.opacity="1";
  }
  
  Ope2.style="";
  Ope3.style="";
  Ope4.style="";
  
}

// 減算
Ope2.onclick=function(){
  if(AnsCount==1){
    Formula=Ans;
  }
  
  if(Ope1Count!=0){
    Formula=Total+Number(Formula);
    document.getElementById("CalAns").value=Number(Formula).toLocaleString();

  }else if(Ope3Count!=0){
    Formula=Total*Number(Formula);
    document.getElementById("CalAns").value=Number(Formula).toLocaleString();

  }else if(Ope4Count!=0){
    Formula=Total/Number(Formula);
    document.getElementById("CalAns").value=Number(Formula).toLocaleString();

  }

  Total=Number(Formula);
  Formula="";
  
  Ope1Count=0;
  Ope2Count=1;
  Ope3Count=0;
  Ope4Count=0;

  DotCount=0;
  if(Ope2Count==1){
    Ope2.style.boxShadow="none";
    Ope2.style.transform="translate(2px,2px)";
    Ope2.style.opacity="1";
  }
  
  Ope1.style="";
  Ope3.style="";
  Ope4.style="";
}

// 乗算
Ope3.onclick=function(){
  if(AnsCount==1){
    Formula=Ans;
  }
  
  if(Ope2Count!=0){
    Formula=Total-Number(Formula);
    document.getElementById("CalAns").value=Number(Formula).toLocaleString();

  }else if(Ope1Count!=0){
    Formula=Total+Number(Formula);
    document.getElementById("CalAns").value=Number(Formula).toLocaleString();

  }else if(Ope4Count!=0){
    Formula=Total/Number(Formula);
    document.getElementById("CalAns").value=Number(Formula).toLocaleString();

  }

  Total=Number(Formula);
  Formula="";
  
  Ope1Count=0;
  Ope2Count=0;
  Ope3Count=1;
  Ope4Count=0;

  DotCount=0;
  if(Ope3Count==1){
    Ope3.style.boxShadow="none";
    Ope3.style.transform="translate(2px,2px)";
    Ope3.style.opacity="1";
  }
  
  Ope1.style="";
  Ope2.style="";
  Ope4.style="";
}

// 減算
Ope4.onclick=function(){
  if(AnsCount==1){
    Formula=Ans;
  }
  
  if(Ope2Count!=0){
    Formula=Total-Number(Formula);
    document.getElementById("CalAns").value=Number(Formula).toLocaleString();

  }else if(Ope3Count!=0){
    Formula=Total*Number(Formula);
    document.getElementById("CalAns").value=Number(Formula).toLocaleString();

  }else if(Ope1Count!=0){
    Formula=Total+Number(Formula);
    document.getElementById("CalAns").value=Number(Formula).toLocaleString();

  }

  Total=Number(Formula);
  Formula="";
  
  Ope1Count=0;
  Ope2Count=0;
  Ope3Count=0;
  Ope4Count=1;

  DotCount=0;
  if(Ope4Count==1){
    Ope4.style.boxShadow="none";
    Ope4.style.transform="translate(2px,2px)";
    Ope4.style.opacity="1";
  }
  
  Ope1.style="";
  Ope2.style="";
  Ope3.style="";
}